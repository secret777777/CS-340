from pymongo import MongoClient

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB."""
    
    def __init__(self, username='aacuser', password='adam1'):
        # Initialize the MongoClient
        self.client = mongodb://{username}:{password}@nv-desktop-services.apporto.com:33945/AAC?authSource=AAC&tls=true

        self.database = self.client['AAC']
    
    # Create method
    def create(self, data):
        if data:
            result = self.database.animals.insert_one(data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method
    def read(self, searchData=None):
        if searchData is None:
            searchData = {}
        
        # Retrieve data from the database
        data = list(self.database.animals.find(searchData, {"_id": False}))
        
        # Convert 'null' values to Python-compatible 'None'
        for record in data:
            for key, value in record.items():
                if value == 'null':
                    record[key] = None
        return data

    # Update method
    def update(self, searchData, updateData):
        if searchData:
            result = self.database.animals.update_many(searchData, {"$set": updateData})
            return result.raw_result
        else:
            raise Exception("Search data parameter is empty")

    # Delete method
    def delete(self, deleteData):
        if deleteData:
            result = self.database.animals.delete_many(deleteData)
            return result.raw_result
        else:
            raise Exception("Delete data parameter is empty")
